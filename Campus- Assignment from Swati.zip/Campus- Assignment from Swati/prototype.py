# Campus Event Management Platform - Prototype Implementation

import sqlite3
import json
from datetime import datetime, timedelta
from typing import List, Dict, Optional
import uuid

class CampusEventManager:
    def __init__(self, db_path: str = "campus_events.db"):
        self.db_path = db_path
        self.init_database()
    
    def init_database(self):
        """Initialize the database with required tables"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        # Create tables
        cursor.executescript("""
            CREATE TABLE IF NOT EXISTS colleges (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL,
                code TEXT UNIQUE NOT NULL,
                location TEXT,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            );
            
            CREATE TABLE IF NOT EXISTS users (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                college_id INTEGER,
                email TEXT UNIQUE NOT NULL,
                name TEXT NOT NULL,
                role TEXT NOT NULL CHECK (role IN ('admin', 'student')),
                student_id TEXT,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (college_id) REFERENCES colleges (id)
            );
            
            CREATE TABLE IF NOT EXISTS events (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                college_id INTEGER,
                title TEXT NOT NULL,
                description TEXT,
                type TEXT NOT NULL CHECK (type IN ('hackathon', 'workshop', 'tecktalk', 'fest', 'seminar')),
                organizer_id INTEGER,
                capacity INTEGER,
                location TEXT,
                start_datetime TIMESTAMP,
                end_datetime TIMESTAMP,
                registration_deadline TIMESTAMP,
                status TEXT DEFAULT 'published' CHECK (status IN ('draft', 'published', 'cancelled', 'completed')),
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (college_id) REFERENCES colleges (id),
                FOREIGN KEY (organizer_id) REFERENCES users (id)
            );
            
            CREATE TABLE IF NOT EXISTS registrations (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                event_id INTEGER,
                student_id INTEGER,
                registration_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                status TEXT DEFAULT 'registered' CHECK (status IN ('registered', 'cancelled', 'attended')),
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (event_id) REFERENCES events (id),
                FOREIGN KEY (student_id) REFERENCES users (id),
                UNIQUE(event_id, student_id)
            );
            
            CREATE TABLE IF NOT EXISTS attendance (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                registration_id INTEGER,
                check_in_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                check_in_method TEXT DEFAULT 'manual',
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (registration_id) REFERENCES registrations (id)
            );
            
            CREATE TABLE IF NOT EXISTS feedback (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                registration_id INTEGER,
                rating INTEGER CHECK (rating >= 1 AND rating <= 5),
                comments TEXT,
                submitted_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (registration_id) REFERENCES registrations (id)
            );
            
            -- Create indexes for better performance
            CREATE INDEX IF NOT EXISTS idx_events_college_date ON events (college_id, start_datetime);
            CREATE INDEX IF NOT EXISTS idx_registrations_event ON registrations (event_id);
            CREATE INDEX IF NOT EXISTS idx_registrations_student ON registrations (student_id);
        """)
        
        conn.commit()
        conn.close()
    
    def create_college(self, name: str, code: str, location: str) -> int:
        """Create a new college"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        cursor.execute(
            "INSERT INTO colleges (name, code, location) VALUES (?, ?, ?)",
            (name, code, location)
        )
        
        college_id = cursor.lastrowid
        conn.commit()
        conn.close()
        return college_id
    
    def create_user(self, college_id: int, email: str, name: str, role: str, student_id: str = None) -> int:
        """Create a new user (admin or student)"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        cursor.execute(
            "INSERT INTO users (college_id, email, name, role, student_id) VALUES (?, ?, ?, ?, ?)",
            (college_id, email, name, role, student_id)
        )
        
        user_id = cursor.lastrowid
        conn.commit()
        conn.close()
        return user_id
    
    def create_event(self, college_id: int, title: str, description: str, event_type: str,
                    organizer_id: int, capacity: int, location: str, 
                    start_datetime: str, end_datetime: str, registration_deadline: str) -> int:
        """Create a new event"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        cursor.execute("""
            INSERT INTO events (college_id, title, description, type, organizer_id, capacity, 
                              location, start_datetime, end_datetime, registration_deadline)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, (college_id, title, description, event_type, organizer_id, capacity, 
              location, start_datetime, end_datetime, registration_deadline))
        
        event_id = cursor.lastrowid
        conn.commit()
        conn.close()
        return event_id
    
    def register_student(self, event_id: int, student_id: int) -> bool:
        """Register a student for an event"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        try:
            # Check if event has capacity
            cursor.execute("""
                SELECT capacity, 
                       (SELECT COUNT(*) FROM registrations WHERE event_id = ? AND status = 'registered') as current_registrations
                FROM events WHERE id = ?
            """, (event_id, event_id))
            
            result = cursor.fetchone()
            if result and result[1] >= result[0]:  # current_registrations >= capacity
                return False
            
            cursor.execute(
                "INSERT INTO registrations (event_id, student_id) VALUES (?, ?)",
                (event_id, student_id)
            )
            
            conn.commit()
            return True
            
        except sqlite3.IntegrityError:
            # Student already registered
            return False
        finally:
            conn.close()
    
    def mark_attendance(self, registration_id: int) -> bool:
        """Mark attendance for a registration"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        # Check if registration exists and hasn't been attended yet
        cursor.execute("""
            SELECT id FROM registrations 
            WHERE id = ? AND status = 'registered'
        """, (registration_id,))
        
        if not cursor.fetchone():
            conn.close()
            return False
        
        # Update registration status and create attendance record
        cursor.execute(
            "UPDATE registrations SET status = 'attended' WHERE id = ?",
            (registration_id,)
        )
        
        cursor.execute(
            "INSERT INTO attendance (registration_id) VALUES (?)",
            (registration_id,)
        )
        
        conn.commit()
        conn.close()
        return True
    
    def collect_feedback(self, registration_id: int, rating: int, comments: str = "") -> bool:
        """Collect feedback for an attended event"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        # Check if student attended the event
        cursor.execute("""
            SELECT id FROM registrations 
            WHERE id = ? AND status = 'attended'
        """, (registration_id,))
        
        if not cursor.fetchone():
            conn.close()
            return False
        
        cursor.execute(
            "INSERT INTO feedback (registration_id, rating, comments) VALUES (?, ?, ?)",
            (registration_id, rating, comments)
        )
        
        conn.commit()
        conn.close()
        return True
    
    def get_event_popularity_report(self) -> List[Dict]:
        """Get event popularity report sorted by registrations"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        cursor.execute("""
            SELECT e.id, e.title, e.type, c.name as college_name,
                   COUNT(r.id) as total_registrations,
                   COUNT(CASE WHEN r.status = 'attended' THEN 1 END) as total_attendance,
                   ROUND(AVG(f.rating), 2) as avg_rating
            FROM events e
            JOIN colleges c ON e.college_id = c.id
            LEFT JOIN registrations r ON e.id = r.event_id
            LEFT JOIN feedback f ON r.id = f.registration_id
            GROUP BY e.id, e.title, e.type, c.name
            ORDER BY total_registrations DESC
        """)
        
        results = []
        for row in cursor.fetchall():
            results.append({
                'event_id': row[0],
                'title': row[1],
                'type': row[2],
                'college': row[3],
                'total_registrations': row[4],
                'total_attendance': row[5],
                'attendance_percentage': round((row[5] / row[4] * 100) if row[4] > 0 else 0, 2),
                'avg_rating': row[6] if row[6] else 0
            })
        
        conn.close()
        return results
    
    def get_student_participation_report(self) -> List[Dict]:
        """Get student participation report"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        cursor.execute("""
            SELECT u.id, u.name, u.email, c.name as college_name,
                   COUNT(r.id) as events_registered,
                   COUNT(CASE WHEN r.status = 'attended' THEN 1 END) as events_attended,
                   ROUND(AVG(f.rating), 2) as avg_feedback_rating
            FROM users u
            JOIN colleges c ON u.college_id = c.id
            LEFT JOIN registrations r ON u.id = r.student_id
            LEFT JOIN feedback f ON r.id = f.registration_id
            WHERE u.role = 'student'
            GROUP BY u.id, u.name, u.email, c.name
            HAVING events_registered > 0
            ORDER BY events_attended DESC, events_registered DESC
        """)
        
        results = []
        for row in cursor.fetchall():
            results.append({
                'student_id': row[0],
                'name': row[1],
                'email': row[2],
                'college': row[3],
                'events_registered': row[4],
                'events_attended': row[5],
                'attendance_rate': round((row[5] / row[4] * 100) if row[4] > 0 else 0, 2),
                'avg_feedback_rating': row[6] if row[6] else 0
            })
        
        conn.close()
        return results
    
    def get_top_active_students(self, limit: int = 3) -> List[Dict]:
        """Get top N most active students"""
        participation_report = self.get_student_participation_report()
        return participation_report[:limit]
    
    def get_attendance_percentage_report(self, event_id: int = None) -> Dict:
        """Get attendance percentage for events"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        if event_id:
            cursor.execute("""
                SELECT e.id, e.title,
                       COUNT(r.id) as total_registrations,
                       COUNT(CASE WHEN r.status = 'attended' THEN 1 END) as total_attendance
                FROM events e
                LEFT JOIN registrations r ON e.id = r.event_id
                WHERE e.id = ?
                GROUP BY e.id, e.title
            """, (event_id,))
        else:
            cursor.execute("""
                SELECT e.id, e.title,
                       COUNT(r.id) as total_registrations,
                       COUNT(CASE WHEN r.status = 'attended' THEN 1 END) as total_attendance
                FROM events e
                LEFT JOIN registrations r ON e.id = r.event_id
                GROUP BY e.id, e.title
                ORDER BY total_registrations DESC
            """)
        
        results = []
        for row in cursor.fetchall():
            attendance_percentage = round((row[3] / row[2] * 100) if row[2] > 0 else 0, 2)
            results.append({
                'event_id': row[0],
                'title': row[1],
                'total_registrations': row[2],
                'total_attendance': row[3],
                'attendance_percentage': attendance_percentage
            })
        
        conn.close()
        return results if not event_id else results[0] if results else None


# Sample data population and testing
def populate_sample_data(manager):
    """Populate database with sample data for testing"""
    
    # Create colleges
    college1_id = manager.create_college("Tech University", "TU", "Bangalore")
    college2_id = manager.create_college("Engineering College", "EC", "Mumbai")
    
    # Create users
    admin1_id = manager.create_user(college1_id, "admin@techuni.edu", "John Admin", "admin")
    student1_id = manager.create_user(college1_id, "student1@techuni.edu", "Alice Student", "student", "TU001")
    student2_id = manager.create_user(college1_id, "student2@techuni.edu", "Bob Student", "student", "TU002")
    student3_id = manager.create_user(college2_id, "student3@ec.edu", "Carol Student", "student", "EC001")
    
    # Create events
    event1_id = manager.create_event(
        college1_id, "AI Hackathon 2025", "48-hour AI/ML hackathon", "hackathon",
        admin1_id, 50, "Main Auditorium",
        "2025-09-15 09:00:00", "2025-09-17 18:00:00", "2025-09-14 23:59:59"
    )
    
    event2_id = manager.create_event(
        college1_id, "React Workshop", "Learn React from basics", "workshop",
        admin1_id, 30, "Lab 1",
        "2025-09-20 14:00:00", "2025-09-20 17:00:00", "2025-09-19 23:59:59"
    )
    
    # Register students
    manager.register_student(event1_id, student1_id)
    manager.register_student(event1_id, student2_id)
    manager.register_student(event2_id, student1_id)
    
    # Mark attendance
    conn = sqlite3.connect(manager.db_path)
    cursor = conn.cursor()
    cursor.execute("SELECT id FROM registrations WHERE event_id = ? AND student_id = ?", (event1_id, student1_id))
    reg_id = cursor.fetchone()[0]
    manager.mark_attendance(reg_id)
    
    # Collect feedback
    manager.collect_feedback(reg_id, 5, "Great event!")
    
    conn.close()
    
    return {
        'college_ids': [college1_id, college2_id],
        'event_ids': [event1_id, event2_id],
        'student_ids': [student1_id, student2_id, student3_id]
    }


# Main execution and demonstration
if __name__ == "__main__":
    # Initialize the system
    manager = CampusEventManager()
    
    # Populate with sample data
    print("Populating sample data...")
    sample_data = populate_sample_data(manager)
    
    print("\n" + "="*50)
    print("CAMPUS EVENT MANAGEMENT SYSTEM - REPORTS")
    print("="*50)
    
    # Generate reports
    print("\n1. EVENT POPULARITY REPORT")
    print("-" * 30)
    popularity_report = manager.get_event_popularity_report()
    for event in popularity_report:
        print(f"Event: {event['title']}")
        print(f"  Type: {event['type']}")
        print(f"  College: {event['college']}")
        print(f"  Registrations: {event['total_registrations']}")
        print(f"  Attendance: {event['total_attendance']} ({event['attendance_percentage']}%)")
        print(f"  Avg Rating: {event['avg_rating']}")
        print()
    
    print("\n2. STUDENT PARTICIPATION REPORT")
    print("-" * 35)
    participation_report = manager.get_student_participation_report()
    for student in participation_report:
        print(f"Student: {student['name']}")
        print(f"  Email: {student['email']}")
        print(f"  College: {student['college']}")
        print(f"  Events Registered: {student['events_registered']}")
        print(f"  Events Attended: {student['events_attended']} ({student['attendance_rate']}%)")
        print(f"  Avg Feedback: {student['avg_feedback_rating']}")
        print()
    
    print("\n3. TOP 3 MOST ACTIVE STUDENTS")
    print("-" * 32)
    top_students = manager.get_top_active_students(3)
    for i, student in enumerate(top_students, 1):
        print(f"{i}. {student['name']} ({student['college']})")
        print(f"   Events Attended: {student['events_attended']}")
        print(f"   Attendance Rate: {student['attendance_rate']}%")
        print()
    
    print("\n4. ATTENDANCE PERCENTAGE REPORT")
    print("-" * 33)
    attendance_report = manager.get_attendance_percentage_report()
    for event in attendance_report:
        print(f"Event: {event['title']}")
        print(f"  Registrations: {event['total_registrations']}")
        print(f"  Attendance: {event['total_attendance']}")
        print(f"  Percentage: {event['attendance_percentage']}%")
        print()
    
    print("Sample data generated successfully!")
    print(f"Database saved as: {manager.db_path}")